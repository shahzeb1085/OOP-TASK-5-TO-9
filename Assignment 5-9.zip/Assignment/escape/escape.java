// \t -> It gives a tab between two words.

class escape {

    public static void main(String[] args)

    {

        System.out.println("This is lab\t 7a! ");

// This \n escape sequence is for a new line.

        System.out.println("Hello! \nThis is Fatima  ");

// The escape sequence \b is a backspace character

// It moves the cursor one character back with

// or without deleting the character (depending upon compiler)

        System.out.println("Good Morning\bg classmates! ");

// This \r escape sequence is a carriage return character

// It moves the output point back to the beginning of the line without moving down a line (usually).

        System.out.println("Good Morning guys! \r How are you all? ");

// This \f escape sequence is a form feed character

// It is an old technique and used to indicate a page break.

        System.out.println("Good Morning! \f How are you all?  ");

// This \' escape sequence is for printing a single quotation mark on the text string

        System.out.println("Wake up \'Pakistan!\' wake up?  ");

// This \\ escape sequence is for printing a backslash on the text string

        System.out.println("\\- this is a backslash. ");

    }

}







